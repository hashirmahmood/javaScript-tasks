const favorite_fruits = ["apple", "mango", "orange"];
if (favorite_fruits.includes("mango")) {
  console.log("You really like mangoes");
}
if (favorite_fruits.includes("date")) {
  console.log("You really like dates");
}
if (favorite_fruits.includes("apple")) {
  console.log("You really like apples");
}
if (favorite_fruits.includes("lemon")) {
  console.log("You really like lemons");
}
if (favorite_fruits.includes("banana")) {
  console.log("You really like bananas");
}
if (favorite_fruits.includes("orange")) {
  console.log("You really like oranges");
}
