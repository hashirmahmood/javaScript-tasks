let alien_color = "green";

if (alien_color == "green") {
  console.log("Player earned 5 points");
} else if (alien_color == "yellow") {
  console.log("Player earned 10 points");
} else if (alien_color == "red") {
  console.log("Player earned 15 points");
}

alien_color = "yellow";
if (alien_color == "green") {
  console.log("Player earned 5 points");
} else if (alien_color == "yellow") {
  console.log("Player earned 10 points");
} else if (alien_color == "red") {
  console.log("Player earned 15 points");
}

alien_color = "red";
if (alien_color == "green") {
  console.log("Player earned 5 points");
} else if (alien_color == "yellow") {
  console.log("Player earned 10 points");
} else if (alien_color == "red") {
  console.log("Player earned 15 points");
}
