let alien_color = "green";
if (alien_color == "green") {
  console.log("Player earned 5 points");
} else {
  console.log("Player earned 10 points");
}

//
alien_color = "red";
if (alien_color == "green") {
  console.log("Player earned 5 points");
} else {
  console.log("Player earned 10 points");
}
