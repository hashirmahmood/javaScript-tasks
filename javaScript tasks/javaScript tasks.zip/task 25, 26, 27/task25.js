let alien_color = "green";
if (alien_color == "green") {
  console.log("Player earned 5 points");
}

//
alien_color = "red";
if (alien_color == "green") {
  console.log("player earned 5 points");
}
