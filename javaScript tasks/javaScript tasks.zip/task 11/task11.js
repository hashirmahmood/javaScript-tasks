let names = ["ahmed", "ali", "umair", "saad"];
names.forEach((x) => {
  console.log(x);
});
