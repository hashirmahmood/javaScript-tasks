let names = ["ahmed", "ali", "umair", "saad"];
names.forEach((x) => {
  console.log(`Hello ${x}, you are my good friend `);
});
