let fav = 7;
let message = `${fav} is my favorite number`;
console.log(message);
