const object = {
  country: "Pakistan",
  river: "Ravi",
  mountain: "K-2",
  color: "Black",
  city: "Lahore",
};
console.log(object);
