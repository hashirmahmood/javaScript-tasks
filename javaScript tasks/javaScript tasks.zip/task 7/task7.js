console.log(5 + 3);
console.log(10 - 2);
console.log(80 / 10);
console.log(2 * 4);
