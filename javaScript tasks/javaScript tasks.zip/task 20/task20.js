const array = ["USA", "France", "Germany", "Pakistan", "Italy"];
console.log(array);
