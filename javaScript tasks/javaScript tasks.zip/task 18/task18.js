let places = ["paris", "berlin", "rome", "kashmir", "newyork"];
//
console.log(places);

//
let placesSort = places;
console.log("\nSorted array: ", placesSort.sort());

//
console.log("\nOriginal array:", places);
