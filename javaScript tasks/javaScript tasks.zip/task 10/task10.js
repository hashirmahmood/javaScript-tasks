//this program displays sum of two numbers
let num1 = 10;
let num2 = 20;
console.log(num1 + num2);

//this program displays product of two numbers
let num3 = 2;
let num4 = 8;
console.log(num3 * num4);
