const guest = ["Faraz", "Rizwan", "Hashir", "Umair"];
guest.forEach((a) => {
  console.log(`Dear ${a}, i've invited you to dinner at my house`);
});
