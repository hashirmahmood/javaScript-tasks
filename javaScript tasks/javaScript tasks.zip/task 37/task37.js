function make_shirt(size = "large", message = "i love javaScript") {
  console.log(`\nthe size of the shirt is ${size}`);
  console.log(message);
}

make_shirt();
make_shirt("medium");
make_shirt("small", "i love python, hehe");
