let name1 = "\thashir mahmood  ";
console.log(name1);
console.log(name1.replace("\t", ""));
