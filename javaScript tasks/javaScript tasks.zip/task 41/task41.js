const magicians = ["david", "peter", "adam", "parker"];
const show_magicians = (array) => {
  array.forEach((x) => {
    console.log(x);
  });
};
show_magicians(magicians);
