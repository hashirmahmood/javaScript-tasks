function make_shirt(size, message) {
  console.log(`the size of the shirt is ${size}`);
  console.log(message);
}

make_shirt(32, "make peace");
