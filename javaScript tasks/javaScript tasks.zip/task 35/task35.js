const animals = ["wolf", "lion", "bear"];
for (let i = 0; i < animals.length; i++) {
  console.log(`a ${animals[i]} is a brave animal`);
}
console.log(
  `The thing which all these three animals have in common is that they all eat meat`
);
