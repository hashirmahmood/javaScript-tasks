let pizza = ["spicy ranch", "chicken fajita", "chicken supreme"];
for (let i = 0; i < pizza.length; i++) {
  console.log(`i like ${pizza[i]} pizza`);
}
console.log("i really love pizza!");
