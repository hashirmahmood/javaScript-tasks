const city_country = (city, country) => {
  return `${city},${country}`;
};
console.log(city_country("Karachi", "Pakistan"));
console.log(city_country("London", "United Kingdom"));
console.log(city_country("Berlin", "Germany"));
