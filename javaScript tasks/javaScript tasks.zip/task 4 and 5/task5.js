let famous_person = "J.K Rowling";
let qoute = '"What is life, Without a little Risk?"';
console.log(`${famous_person} once said: ${qoute}`);
