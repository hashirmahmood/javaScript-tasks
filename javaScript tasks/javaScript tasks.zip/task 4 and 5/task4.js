console.log('J.K once said, "What is life, Without a little Risk?" ');
