let users = ["ahmed", "ali", "admin", "usman", "habib", "omar"];
if (users == "") {
  console.log("We need to find some users");
}
users = [];
if (users == "") {
  console.log("We need to find some users");
}
